<?php
/*
Plugin Name: My Streamlit
Description: Ein Plugin, um Streamlit und WordPress zu integrieren
Version:     1.0
Author:      Keyvan Hardani
*/

// Sicherstellen, dass kein direkter Zugriff auf die Datei möglich ist
defined('ABSPATH') or die('Direct script access disallowed.');

function my_streamlit_plugin_menu() {
    add_menu_page(
        'Streamlit Plugin Seite', 
        'Streamlit Plugin', 
        'manage_options', 
        'streamlit-plugin', 
        'my_streamlit_plugin_page', 
        '', 
        20
    );
}

add_action('admin_menu', 'my_streamlit_plugin_menu');

function my_streamlit_plugin_page() {
    ?>
    <div class="wrap">
        <h1>Streamlit Plugin Einstellungen</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('my_streamlit_plugin_settings');
            do_settings_sections('my_streamlit_plugin_settings');
            ?>
            <table class="form-table">
                <tr valign="top">
                <th scope="row">API Schlüssel</th>
                <td><input type="text" name="api_key" value="<?php echo get_option('api_key'); ?>" /></td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

function my_streamlit_plugin_settings() {
    register_setting('my_streamlit_plugin_settings', 'api_key');
}

add_action('admin_init', 'my_streamlit_plugin_settings');

/**
* JWT Plugin for Streamlit
**/

add_filter('jwt_auth_expire', 'set_jwt_auth_expire');
function set_jwt_auth_expire() {
  return time() + (60*30);  // 30 minutes
}

add_action('rest_api_init', 'add_api_key_check');
function add_api_key_check() {
  if (!isset($_SERVER['HTTP_X_API_KEY']) || $_SERVER['HTTP_X_API_KEY'] != get_option('api_key')) {
    wp_die('Incorrect API Key');
  }
}
